package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.repository.AccountRepository;

@Component
public class AccountService implements AccountServiceI {
	
	@Autowired
	private AccountRepository accountRepository;
	
	public Account saveAccount(Account account){
		return accountRepository.save(account);
	}
	
	public List<Account> saveAccunts(List<Account> account){
		return accountRepository.saveAll(account);
	}
	
	public List<Account> getAccounts(){
		return accountRepository.findAll();
	}
	
	public Account getAccuntByCustName(String name){
		return accountRepository.findByCustName(name);
	}
	
	public Account getAccuntByAccountNum(int accountNum){
		return accountRepository.findByAccountNum(accountNum);
	}
	
	public String deleteAccount(int accountNum){
		accountRepository.deleteAccountByAccountNum(accountNum);
		return "removed by accountNum!!!"+accountNum;
	}
	
	public Account updateAccount(Account account){
		Account existingAccount=accountRepository.findByAccountNum(account.getAccountNum());
		existingAccount.setAccountNum(account.getAccountNum());
		existingAccount.setBankName(account.getBankName());
		existingAccount.setCustName(account.getCustName());
		existingAccount.setBalanceAmount(account.getBalanceAmount());
		return accountRepository.save(existingAccount);
	}

	public String withdrawAmount(int accountNum, int withdrawAmount) {
		Account existingAccount=accountRepository.findByAccountNum(accountNum);
		if(existingAccount.getBalanceAmount()<withdrawAmount)
			return "Withdrawal failed due to insufficient amount in the account.";
		existingAccount.setBalanceAmount(existingAccount.getBalanceAmount()-withdrawAmount);
		accountRepository.save(existingAccount);
		return "Withdrawal Successfully";
	}

	public String transfer(int accountNum01, int accountNum02, int transferAmount) {
		Account account01=accountRepository.findByAccountNum(accountNum01);
		Account account02=accountRepository.findByAccountNum(accountNum02);
		if(account01==null || account02==null)
			return "Invalid Account Number. Please Check";
		if(account01.getBalanceAmount()<transferAmount)
			return "transfer failed due to insufficient amount in the account.";
		account01.setBalanceAmount(account01.getBalanceAmount()-transferAmount);
		account02.setBalanceAmount(account02.getBalanceAmount()+transferAmount);
		accountRepository.save(account01);
		accountRepository.save(account02);
		return "transfered Successfully.";
	}
}
