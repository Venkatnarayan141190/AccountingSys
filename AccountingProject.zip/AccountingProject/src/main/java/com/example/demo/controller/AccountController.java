package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Account;
import com.example.demo.service.AccountServiceI;

@RestController
public class AccountController {

	@Autowired
	private AccountServiceI accountService;
	
	@PostMapping("/addAccount")
	public Account addAccount(@RequestBody Account account){
		return accountService.saveAccount(account);	
	}
	
	@PostMapping("/addAccounts")
	public List<Account> addAccount(@RequestBody List<Account> accounts){
		return accountService.saveAccunts(accounts);	
	}
	
	@GetMapping("/accounts")
	public List<Account> findAllAccounts(){
		return accountService.getAccounts();
	}
	
	@GetMapping("/accountByName/{name}")
	public Account findAllAccountsByName(@PathVariable String name){
		return accountService.getAccuntByCustName(name);
	}
	
	@GetMapping("/accountByAccountNum/{accountNum}")
	public Account findAllAccountsByAccountNum(@PathVariable int accountNum){
		return accountService.getAccuntByAccountNum(accountNum);
	}
	
	@PutMapping("/update")
	public Account updateAccount(@PathVariable Account account){
		return accountService.updateAccount(account);
	}
	
	@DeleteMapping("/delete/{accountNum}")
	public String deleteAccount(@PathVariable int accountNum){
		return accountService.deleteAccount(accountNum);
	}
	
	@PutMapping("/withdrawal/{accountNum}/{withdrawAmount}")
	public String withdrawAmount(@PathVariable int accountNum, @PathVariable int withdrawAmount){
		return accountService.withdrawAmount(accountNum,withdrawAmount);
	}
	
	@PutMapping("/transfer/{accountNum01}/{accountNum02}/{withdrawAmount}")
	public String transfer(@PathVariable int accountNum01, @PathVariable int accountNum02, @PathVariable int withdrawAmount){
		return accountService.transfer(accountNum01,accountNum02, withdrawAmount);
	}
}
